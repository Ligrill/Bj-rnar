
var myButton = document.getElementById("myButton");


myButton.addEventListener("click", function() {
    
    alert("björnar har förmågan att lösa problem och använda verktyg som exempelvis stenar eller stockar för att nå mat.");
});
